const nsfwmenu = (prefix, pushname) => {
    return `OPA SAFRADO KKKK, AQUI �0�7 O MENU DE *NSFW*
  ┄1�7
  ├─ ❄1�7 ${prefix}nsfwbobs
  ├─ ❄1�7 ${prefix}randomhentaio
  ├─ ❄1�7 ${prefix}nsfwtrap
  ├─ ❄1�7 ${prefix}nsfwass
  ├─ ❄1�7 ${prefix}nsfwbelly
  ├─ ❄1�7 ${prefix}nsfwsidebobs
  ├─ ❄1�7 ${prefix}nsfwahegao
  ├─ ❄1�7 ${prefix}nsfwthighs
  ├─ ❄1�7 ${prefix}nsfwarmpits
  └─ ❄1�7 ${prefix}nsfwfeets

  _obs para usar esses comandos ative o menu NSFW_\n _Digite_\n ${prefix}*nsfw 1*`



}

exports.nsfwmenu = nsfwmenu
