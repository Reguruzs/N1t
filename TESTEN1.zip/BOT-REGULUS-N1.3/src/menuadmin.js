const menuadmin = (prefix, pushname) => {
 return `EAE, AQUI É O MENU DOS ADMS (só pode ser executado por adms, e em grupos)_
 
 ♕-♱ಝ C⃟ O⃟ M⃟ A⃟ N⃟ D⃟ O⃟ S⃟.  ಝ♱-♕
 │
 ├─ ♕ ${prefix}opengc
 ├─ ♕ ${prefix}closegc
 ├─ ♕ ${prefix}promote
 ├─ ♕ ${prefix}demote
 ├─ ♕ ${prefix}tagall
 ├─ ♕ ${prefix}tagall2
 ├─ ♕ ${prefix}tagall3
 ├─ ♕ ${prefix}tagall4
 ├─ ♕ ${prefix}tagall5
 ├─ ♕ ${prefix}add
 ├─ ♕ ${prefix}remover
 ├─ ♕ ${prefix}listadmins
 ├─ ♕ ${prefix}linkgroup
 ├─ ♕ ${prefix}leave
 ├─ ♕ ${prefix}welcome
 ├─ ♕ ${prefix}nsfw
 ├─ ♕ ${prefix}leveling
 ├─ ♕ ${prefix}level
 ├─ ♕ ${prefix}delete
 ├─ ♕ ${prefix}simih
 └─ ♕ ${prefix}ownergroup
 `


}

exports.menuadmin = menuadmin
